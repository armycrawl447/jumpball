//
//  SalesDataTableViewCell.swift
//  LoginScreenApp
//
//  Created by administrator on 2/4/17.
//  Copyright © 2017 kaleidosstudio. All rights reserved.
//

import UIKit

class SalesDataTableViewCell: UITableViewCell {

    @IBOutlet weak var salesData: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
