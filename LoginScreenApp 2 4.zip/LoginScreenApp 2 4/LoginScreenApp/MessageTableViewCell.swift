//
//  MessageTableViewCell.swift
//  LoginScreenApp
//
//  Created by administrator on 2/2/17.
//  Copyright © 2017 kaleidosstudio. All rights reserved.
//

import UIKit

class MessageTableViewCell: UITableViewCell {

    @IBOutlet weak var msgContent: UILabel!
    @IBOutlet weak var created: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
