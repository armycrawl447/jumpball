//
//  SalesViewController.swift
//  LoginScreenApp
//
//  Created by administrator on 1/30/17.
//  Copyright © 2017 kaleidosstudio. All rights reserved.
//

import UIKit

class SalesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var tableView : UITableView!
    var salesArray = [String]()
    
    let sales_url = "https://www.distribber.com/api/resources/get_films_sales/4464"
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return salesArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "salesData1", for:indexPath) as! SalesDataTableViewCell
        // Configuring Cell
        cell.salesData.text = salesArray[indexPath.row]
        // Returning the cell
        return cell
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        
        let url:URL = URL(string: sales_url)!
        let session = URLSession.shared
        
        let request = NSMutableURLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("740c94c51891c02b64d6c78840b478fe0b02fe2c", forHTTPHeaderField: "X-API-KEY")
        request.setValue("Basic YmhlZW0uZW5nckBnbWFpbC5jb206YmgzM20=", forHTTPHeaderField: "Authorization")
        request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
        let paramString = ""
        
        request.httpBody = paramString.data(using: String.Encoding.utf8)
        
        let task = session.dataTask(with: request as URLRequest, completionHandler: {
            (
            data, response, error) in
            
            guard let _:Data = data, let _:URLResponse = response  , error == nil else {
                
                return
            }
            
            
            
            var json:Any?
            
            do
            {
                
                if let existingData = data {
                    json = try JSONSerialization.jsonObject(with: existingData, options: [])
                    print(json)
                    print(NSString(data: existingData, encoding: String.Encoding.utf8.rawValue))
                }
                
                //  Prasing JSON
                 if let parsedData = json as? [[String:Any]] {
                    for dict in parsedData {
                        if let title = dict["title"] as? String {
                        if let AmazonSales = dict["AmazonSales"] as? String {
                             if let GoogleSales = dict["GoogleSales"] as? String {
                                 if let HuluSales = dict["HuluSales"] as? String {
                                     if let VuduSales = dict["VuduSales"] as? String {
                                         if let iTunesSales = dict["iTunesSales"] as? String {
                            self.salesArray.append(AmazonSales)
                                            self.salesArray.append(GoogleSales)
                                            self.salesArray.append(HuluSales)
                                            self.salesArray.append(VuduSales)
                                            self.salesArray.append(iTunesSales)
                                            self.salesArray.append(title)
                            print(json) // --  THis Print is not working
                        
                                        
                                        }
                                        }
                                        }
                                        }
                                        }
                        }
                    }
                    
                    OperationQueue.main.addOperation({
                        self.tableView.reloadData()
                    })
                }
            }
            catch
            {
                return
            }
            
            guard let server_response = json as? NSDictionary else
            {
                return
            }
            
            if let data_block = server_response["data"] as? NSDictionary
            {
                if let session_data = data_block["session"] as? String
                {
                    //  self.login_session = session_data
                    
                    let preferences = UserDefaults.standard
                    preferences.set(session_data, forKey: "session")
                    
                    //  DispatchQueue.main.async(execute: self.LoginDone)
                }
            }
        })
        
        task.resume()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
}
