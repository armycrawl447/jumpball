//
//  MCViewController.swift
//  LoginScreenApp
//
//  Created by administrator on 1/30/17.
//  Copyright © 2017 kaleidosstudio. All rights reserved.
//

import UIKit

class MCViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    let message_url = "https://www.distribber.com/api/resources/get_film_message/film_id/3825"
    let send_url = "https://www.distribber.com/api/resources/send_film_message"
    let film_id = "3825"
    var messageArray = [String]()
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messageArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "msgContent", for:indexPath) as! MessageTableViewCell
        // Configuring Cell
        cell.msgContent.text = messageArray[indexPath.row]
        cell.created.text = messageArray[indexPath.row]
        // Returning the cell
        return cell
    }
    
    

    @IBOutlet weak var MessageInput: UITextField!
    @IBAction func Sendmsg(_ sender: Any) {
        Sendmsg(username:MessageInput.text!, password: film_id)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        
        let url:URL = URL(string: message_url)!
        let session = URLSession.shared
        
        let request = NSMutableURLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("740c94c51891c02b64d6c78840b478fe0b02fe2c", forHTTPHeaderField: "X-API-KEY")
        request.setValue("Basic YmhlZW0uZW5nckBnbWFpbC5jb206YmgzM20=", forHTTPHeaderField: "Authorization")
        request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
        // Do any additional setup after loading the view.
        let paramString1 = ""
  
        request.httpBody = paramString1.data(using: String.Encoding.utf8)
        
        let task = session.dataTask(with: request as URLRequest, completionHandler: {
            (
            data, response, error) in
            
            guard let _:Data = data, let _:URLResponse = response  , error == nil else {
                
                return
            }
            
            
            
            var json: Any?
            
            do
            {
                if let existingData = data {
                    json = try JSONSerialization.jsonObject(with: existingData, options: [])
                }

                json = try JSONSerialization.jsonObject(with: data!, options: [])
                if let parsedData = json as? [[String:Any]] {
                    for dict in parsedData {
                        if let message = dict["message"] as? String {
                            self.messageArray.append(message)
                            print(json)
                        }
                    }
                    OperationQueue.main.addOperation({
                        self.tableView.reloadData()
                    })
                }
            }
            catch
            {
                return
            }
            
            guard let server_response = json as? NSDictionary else
            {
                return
            }
            
            
            if let data_block = server_response["data"] as? NSDictionary
            {
                if let session_data = data_block["session"] as? String
                {
                    //  self.login_session = session_data
                    
                    let preferences = UserDefaults.standard
                    preferences.set(session_data, forKey: "session")
                    
                    //  DispatchQueue.main.async(execute: self.LoginDone)
                }
            }
            
            
            
        })
        
        task.resume()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func Sendmsg(username:String, password:String)
    {
        let post_data: NSDictionary = NSMutableDictionary()
        
        
        post_data.setValue(username, forKey: "message")
        post_data.setValue(password, forKey: "film_id")
        
        let url:URL = URL(string: send_url)!
        let session = URLSession.shared
        
        let request = NSMutableURLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("740c94c51891c02b64d6c78840b478fe0b02fe2c", forHTTPHeaderField: "X-API-KEY")
        request.setValue("Basic YmhlZW0uZW5nckBnbWFpbC5jb206YmgzM20=", forHTTPHeaderField: "Authorization")
        request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
        
        var paramString = ""
        
        
        for (key, value) in post_data
        {
            paramString = paramString + (key as! String) + "=" + (value as! String) + "&"
        }
        
        request.httpBody = paramString.data(using: String.Encoding.utf8)
        
        let task = session.dataTask(with: request as URLRequest, completionHandler: {
            (
            data, response, error) in
            
            guard let _:Data = data, let _:URLResponse = response  , error == nil else {
                
                return
            }
            
            
            
            let json: Any?
            
            do
            {
                json = try JSONSerialization.jsonObject(with: data!, options: [])
                print(json)
            }
            catch
            {
                return
            }
            
            guard let server_response = json as? NSDictionary else
            {
                return
            }
            
            
//            if let data_block = server_response["data"] as? NSDictionary
//            {
//                if let session_data = data_block["session"] as? String
//                {
//                    self.login_session = session_data
//                    
//                    let preferences = UserDefaults.standard
//                    preferences.set(session_data, forKey: "session")
//                    
//                    DispatchQueue.main.async(execute: self.LoginDone)
//                }
//            }
//            
            
            
        })
        
        task.resume()
        
        
    }

    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
